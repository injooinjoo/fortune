"use client";

import { logger } from '@/lib/logger';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase, userProfileService } from '@/lib/supabase';
import { getUserProfile, saveUserProfile, updateUserProfile } from '@/lib/user-storage';
import AuthSessionManager from '@/lib/auth-session-manager';
import { AuthDebugPanel } from '@/components/debug/AuthDebugPanel';

export default function AuthCallbackPage() {
  const router = useRouter();
  const [isProcessing, setIsProcessing] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [timeoutReached, setTimeoutReached] = useState(false);

  // 클라이언트 사이드 마운트 확인 (hydration 오류 방지)
  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!isClient) return;

    let isProcessed = false; // 중복 처리 방지 플래그
    let timeoutId: NodeJS.Timeout;

    // 10초 타임아웃 설정
    timeoutId = setTimeout(() => {
      if (!isProcessed) {
        logger.error('⏱️ 인증 처리 타임아웃');
        setTimeoutReached(true);
        setIsProcessing(false);
        setErrorMessage('인증 처리가 너무 오래 걸리고 있습니다.');
        setTimeout(() => router.replace('/'), 3000);
      }
    }, 10000);

    const handleAuthCallback = async () => {
      if (isProcessed) return; // 이미 처리된 경우 중단
      isProcessed = true;

      try {
        logger.debug('🔄 Auth callback started at:', new Date().toISOString());
        logger.debug('📍 Full URL:', window.location.href);
        
        // URL에서 직접 파라미터 추출
        const urlParams = new URLSearchParams(window.location.search);
        const urlHash = window.location.hash;
        
        logger.debug('📍 URL params:', urlParams.toString());
        logger.debug('📍 URL hash:', urlHash);

        // localStorage 상태 확인 (PKCE 디버깅)
        if (process.env.NODE_ENV === 'development') {
          const allKeys = Object.keys(localStorage);
          const authKeys = allKeys.filter(key => 
            key.includes('supabase') || key.includes('auth') || 
            key.includes('pkce') || key.includes('code_verifier') ||
            key.startsWith('sb-')
          );
          logger.debug('🔍 Current localStorage auth keys:', authKeys);
          
          // Supabase URL에서 프로젝트 참조 추출
          const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
          const projectRef = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/)?.[1];
          logger.debug('📌 Supabase project reference:', projectRef);
          
          // 각 키의 값 확인 (code_verifier 포함 여부)
          authKeys.forEach(key => {
            const value = localStorage.getItem(key);
            if (value) {
              try {
                const parsed = JSON.parse(value);
                if (parsed.code_verifier || parsed.codeVerifier) {
                  logger.debug(`✅ Found code_verifier in key: ${key}`);
                } else if (parsed.currentSession?.code_verifier) {
                  logger.debug(`✅ Found code_verifier in currentSession of key: ${key}`);
                }
              } catch {
                // JSON이 아닌 경우 단순 문자열 확인
                if (key.includes('code_verifier')) {
                  logger.debug(`📝 Raw code_verifier key found: ${key} = ${value.substring(0, 20)}...`);
                }
              }
            }
          });
        }

        // code 파라미터 확인 (OAuth authorization code)
        const code = urlParams.get('code');
        const error = urlParams.get('error');
        const errorDescription = urlParams.get('error_description');

        // 먼저 현재 세션 확인
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionData?.session && !code) {
          logger.debug('✅ 이미 유효한 세션이 존재합니다');
          const user = sessionData.session.user;
          
          // 기존 세션이 있으면 프로필 확인 후 리다이렉트
          const existingProfile = await userProfileService.getProfile(user.id);
          
          if (existingProfile && existingProfile.onboarding_completed) {
            router.replace('/home');
          } else {
            router.replace('/onboarding');
          }
          return;
        }

        if (error) {
          logger.error('🚨 OAuth error:', error, errorDescription);
          setErrorMessage(`OAuth 인증 오류: ${errorDescription || error}`);
          setIsProcessing(false);
          setTimeout(() => router.replace('/'), 3000);
          return;
        }

        if (code) {
          logger.debug('✅ Authorization code found, exchanging for session...');
          logger.debug('Code:', code.substring(0, 10) + '...');
          
          // 브라우저 확장 프로그램 간섭 확인 및 제거
          const suspiciousKeys = Object.keys(localStorage).filter(key => 
            key.includes('fortune-auth-token-code-verifier') || 
            (key.includes('code-verifier') && !key.startsWith('sb-'))
          );
          
          if (suspiciousKeys.length > 0) {
            logger.warn('🚨 Browser extension interference detected during callback:', suspiciousKeys);
            // 간섭하는 키들 제거
            suspiciousKeys.forEach(key => {
              logger.debug(`Removing interfering key: ${key}`);
              localStorage.removeItem(key);
            });
          }
          
          // Debug: Check localStorage for PKCE code verifier
          if (process.env.NODE_ENV === 'development') {
            const allKeys = Object.keys(localStorage);
            const supabaseKeys = allKeys.filter(key => 
              key.includes('supabase') || key.includes('auth') || key.startsWith('sb-')
            );
            logger.debug('Current localStorage keys:', supabaseKeys);
            
            // Check for code verifier in different possible locations
            const possibleKeys = [
              'supabase.auth.code_verifier',
              'supabase.auth.pkce.code_verifier',
              `sb-hayjukwfcsdmppairazc-auth-token`
            ];
            
            possibleKeys.forEach(key => {
              const value = localStorage.getItem(key);
              if (value) {
                logger.debug(`Found value for ${key}:`, value.substring(0, 20) + '...');
              }
            });
            
            // Check if any key contains code verifier data
            supabaseKeys.forEach(key => {
              const value = localStorage.getItem(key);
              if (value && value.includes('code_verifier')) {
                logger.debug(`Key ${key} contains code_verifier`);
              }
            });
          }
          
          try {
            // code를 session으로 교환
            const { data, error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
            
            if (exchangeError) {
              logger.error('🚨 Code exchange error:', exchangeError);
              
              // PKCE 관련 오류인 경우 특별 처리
              if (exchangeError.message?.includes('code verifier') || 
                  exchangeError.message?.includes('PKCE') ||
                  exchangeError.message?.includes('invalid request')) {
                logger.error('🚨 PKCE verification failed:', exchangeError);
                
                // Supabase의 기본 PKCE 플로우를 사용하도록 다시 시도
                setErrorMessage('PKCE 인증에 실패했습니다. 다시 로그인해주세요.');
                
                // 실패한 인증 데이터만 정리
                AuthSessionManager.resetAuthStorage();
                
                // 사용자를 직접 OAuth URL로 리다이렉트하지 않고 메인 페이지로 보냄
                setTimeout(() => router.replace('/?error=pkce_failure'), 2000);
                return;
              }
              
              setErrorMessage('토큰 교환 중 오류가 발생했습니다.');
              setIsProcessing(false);
              setTimeout(() => router.replace('/'), 3000);
              return;
            }
            
            // 성공 시 임시 데이터 정리
            AuthSessionManager.cleanupAfterAuth();
            
            if (data?.session?.user) {
              const user = data.session.user;
              logger.debug('✅ User authenticated:', user.email);
              
              // 타임아웃 클리어
              clearTimeout(timeoutId);
            
            // 사용자 프로필 확인
            const existingProfile = await userProfileService.getProfile(user.id);
            
            // 로컬 스토리지에서 기존 데이터 확인
            const localProfile = getUserProfile();
            
            if (existingProfile && existingProfile.onboarding_completed) {
              // 기존 사용자 - 로컬 데이터와 병합
              logger.debug('👤 Existing user, merging with local data');
              
              // 로캼 데이터가 있으면 병합
              if (localProfile && localProfile.onboarding_completed) {
                const mergedProfile = {
                  ...existingProfile,
                  // 로캼에서 더 최신 데이터가 있으면 사용
                  name: localProfile.name || existingProfile.name,
                  birth_date: localProfile.birth_date || existingProfile.birth_date,
                  birth_time: localProfile.birth_time || existingProfile.birth_time,
                  mbti: localProfile.mbti || existingProfile.mbti,
                  updated_at: new Date().toISOString()
                };
                
                // Supabase에 업데이트
                await userProfileService.upsertProfile(mergedProfile);
                // 로컬에도 업데이트
                saveUserProfile(mergedProfile);
                logger.debug('🔄 데이터 병합 완료');
              } else {
                // 로컬 데이터가 없으면 Supabase 데이터를 로컬에 저장
                saveUserProfile(existingProfile);
              }
              
              setIsProcessing(false);
              router.replace('/home');
            } else {
              // 신규 사용자 또는 온보딩 미완료
              logger.debug('🆕 New user or onboarding incomplete, redirecting to onboarding');
              
              // 기본 프로필 생성
              if (!existingProfile) {
                const newProfile = {
                  id: user.id,
                  email: user.email,
                  name: user.user_metadata?.full_name || user.email?.split('@')[0] || '사용자',
                  avatar_url: user.user_metadata?.avatar_url,
                  onboarding_completed: false,
                  created_at: new Date().toISOString()
                };
                
                // 로컼 데이터가 있으면 병합
                if (localProfile) {
                  const mergedProfile = {
                    ...newProfile,
                    name: localProfile.name || newProfile.name,
                    birth_date: localProfile.birth_date,
                    birth_time: localProfile.birth_time,
                    mbti: localProfile.mbti,
                    onboarding_completed: localProfile.onboarding_completed || false,
                    updated_at: new Date().toISOString()
                  };
                  
                  await userProfileService.upsertProfile(mergedProfile);
                  saveUserProfile(mergedProfile);
                  logger.debug('🔄 로캼 데이터와 병합한 신규 프로필 생성');
                } else {
                  await userProfileService.upsertProfile(newProfile);
                  saveUserProfile(newProfile);
                }
              }
              
              setIsProcessing(false);
              router.replace('/onboarding');
            }
            } else {
              logger.debug('❌ No session after code exchange');
              setErrorMessage('세션 생성에 실패했습니다.');
              setIsProcessing(false);
              setTimeout(() => router.replace('/'), 3000);
            }
          } catch (codeError) {
            logger.error('🚨 Code exchange exception:', codeError);
            setErrorMessage('인증 처리 중 오류가 발생했습니다.');
            setIsProcessing(false);
            setTimeout(() => router.replace('/'), 3000);
          }
        } else {
          // code도 없고 URL hash에서 session 확인 시도
          logger.debug('🔍 No code found, checking for session from URL...');
          
          const { data, error: sessionError } = await supabase.auth.getSession();
          
          if (sessionError) {
            logger.error('🚨 Session retrieval error:', sessionError);
            setErrorMessage('세션 확인 중 오류가 발생했습니다.');
            setIsProcessing(false);
            setTimeout(() => router.replace('/'), 3000);
            return;
          }

          if (data.session?.user) {
            const user = data.session.user;
            logger.debug('✅ Session found, user:', user.email);
            
            // 사용자 프로필 확인
            const existingProfile = await userProfileService.getProfile(user.id);
            
            // 로컬 스토리지에서 기존 데이터 확인
            const localProfile = getUserProfile();
            
            if (existingProfile && existingProfile.onboarding_completed) {
              logger.debug('👤 Existing user with session, merging with local data');
              
              // 로캼 데이터가 있으면 병합
              if (localProfile && localProfile.onboarding_completed) {
                const mergedProfile = {
                  ...existingProfile,
                  name: localProfile.name || existingProfile.name,
                  birth_date: localProfile.birth_date || existingProfile.birth_date,
                  birth_time: localProfile.birth_time || existingProfile.birth_time,
                  mbti: localProfile.mbti || existingProfile.mbti,
                  updated_at: new Date().toISOString()
                };
                
                await userProfileService.upsertProfile(mergedProfile);
                saveUserProfile(mergedProfile);
                logger.debug('🔄 데이터 병합 완료');
              } else {
                saveUserProfile(existingProfile);
              }
              
              setIsProcessing(false);
              router.replace('/home');
            } else {
              logger.debug('🆕 New user with session, redirecting to onboarding');
              
              if (!existingProfile) {
                const newProfile = {
                  id: user.id,
                  email: user.email,
                  name: user.user_metadata?.full_name || user.email?.split('@')[0] || '사용자',
                  avatar_url: user.user_metadata?.avatar_url,
                  onboarding_completed: false,
                  created_at: new Date().toISOString()
                };
                
                if (localProfile) {
                  const mergedProfile = {
                    ...newProfile,
                    name: localProfile.name || newProfile.name,
                    birth_date: localProfile.birth_date,
                    birth_time: localProfile.birth_time,
                    mbti: localProfile.mbti,
                    onboarding_completed: localProfile.onboarding_completed || false,
                    updated_at: new Date().toISOString()
                  };
                  
                  await userProfileService.upsertProfile(mergedProfile);
                  saveUserProfile(mergedProfile);
                } else {
                  await userProfileService.upsertProfile(newProfile);
                  saveUserProfile(newProfile);
                }
              }
              
              setIsProcessing(false);
              router.replace('/onboarding');
            }
          } else {
            logger.debug('❌ No session found, redirecting to main page');
            setIsProcessing(false);
            router.replace('/');
          }
        }
      } catch (error) {
        logger.error('🚨 Auth callback processing error:', error);
        logger.error('Error stack:', (error as Error).stack);
        setErrorMessage('인증 처리 중 예기치 않은 오류가 발생했습니다.');
        setIsProcessing(false);
        clearTimeout(timeoutId);
        setTimeout(() => router.replace('/'), 3000);
      } finally {
        // 어떤 경우든 타임아웃은 클리어
        if (timeoutId) clearTimeout(timeoutId);
      }
    };

    // 약간의 지연을 두어 DOM이 완전히 로드된 후 실행
    const timer = setTimeout(handleAuthCallback, 100);
    return () => {
      clearTimeout(timer);
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [router, isClient]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {process.env.NODE_ENV === 'development' && <AuthDebugPanel />}
      <div className="text-center max-w-md mx-auto p-6">
        {isProcessing ? (
          <>
            <div className="animate-spin h-8 w-8 border-4 border-purple-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-lg text-gray-900 mb-2">구글 로그인 처리 중...</p>
            <p className="text-sm text-gray-600">
              인증 정보를 확인하고 있습니다...
            </p>
            {timeoutReached && (
              <div className="mt-4">
                <p className="text-sm text-yellow-600">처리가 예상보다 오래 걸리고 있습니다...</p>
                <button
                  onClick={() => router.replace('/')}
                  className="mt-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 text-sm"
                >
                  메인 페이지로 돌아가기
                </button>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="text-red-500 text-6xl mb-4">⚠️</div>
            <p className="text-lg text-gray-900 mb-2">로그인 처리 중 문제가 발생했습니다</p>
            {errorMessage && (
              <p className="text-sm text-red-600 mb-4">{errorMessage}</p>
            )}
            <p className="text-sm text-gray-600">
              잠시 후 메인 페이지로 이동합니다...
            </p>
          </>
        )}
      </div>
    </div>
  );
} 