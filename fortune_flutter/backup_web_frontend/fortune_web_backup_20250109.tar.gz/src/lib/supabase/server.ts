// Supabase 서버 클라이언트 re-export
// Next.js App Router에서는 동일한 클라이언트 사용
export * from '../supabase';
export { supabase as default } from '../supabase';