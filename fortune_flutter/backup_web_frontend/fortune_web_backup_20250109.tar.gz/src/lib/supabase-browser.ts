import { supabase } from './supabase';

export function getSupabaseBrowserClient() {
  return supabase;
}